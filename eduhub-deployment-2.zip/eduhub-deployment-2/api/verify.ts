// This file is deprecated. Please use netlify/functions/verify.ts
export {};