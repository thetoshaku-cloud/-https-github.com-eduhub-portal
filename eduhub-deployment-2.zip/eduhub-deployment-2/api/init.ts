// This file is deprecated. Please use netlify/functions/init.ts
export {};