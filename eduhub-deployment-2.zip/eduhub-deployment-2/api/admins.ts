// This file is deprecated. Please use netlify/functions/admins.ts
export {};