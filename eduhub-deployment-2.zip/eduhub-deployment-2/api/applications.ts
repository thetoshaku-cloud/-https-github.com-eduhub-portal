// This file is deprecated. Please use netlify/functions/applications.ts
export {};